package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Penghapus latar belakang (langkah 2).
 * - Utama: ML Kit Subject Segmentation (berjalan di HP, mengenali objek apa saja).
 * - Cadangan: deteksi warna latar dari tepi foto (cocok untuk latar polos) bila ML Kit tidak tersedia.
 */
object BackgroundRemover {
    /** a = tingkat keyakinan objek 0..1 per piksel, ukuran w x h. */
    class Mask(val w: Int, val h: Int, val a: FloatArray, val fallback: Boolean)

    /**
     * method: 0 = Objek (ML Kit), 1 = Warna latar (flood-fill dari tepi), 2 = Gabungan (keduanya harus setuju).
     * Hanya boleh dipanggil dari thread latar (menunggu hasil ML Kit).
     */
    fun detect(src: Bitmap, method: Int = 0): Mask {
        if (method == 1) return colorMask(src)
        val ml = detectMl(src) ?: return colorMask(src)
        if (method == 2) {
            val c = colorMask(src)
            if (c.w == ml.w && c.h == ml.h) {
                // ML Kit yang yakin (>= 0.85) tidak boleh dibatalkan oleh deteksi warna: benda terang
                // (gaun putih, kemeja putih) di depan latar terang sering salah dianggap latar oleh
                // deteksi warna. Deteksi warna hanya merapikan area yang ML Kit sendiri ragu-ragu.
                val a = FloatArray(ml.a.size) { if (ml.a[it] >= 0.85f) ml.a[it] else min(ml.a[it], c.a[it]) }
                return Mask(ml.w, ml.h, a, false)
            }
        }
        return ml
    }

    private fun detectMl(src: Bitmap): Mask? {
        val w = src.width
        val h = src.height
        try {
            val opts = SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build()
            val seg = SubjectSegmentation.getClient(opts)
            try {
                val res = Tasks.await(seg.process(InputImage.fromBitmap(src, 0)), 120, TimeUnit.SECONDS)
                val buf = res.foregroundConfidenceMask
                if (buf != null) {
                    val arr = FloatArray(w * h)
                    buf.rewind()
                    buf.get(arr, 0, min(arr.size, buf.remaining()))
                    var fg = 0
                    for (v in arr) if (v > 0.5f) fg++
                    // Bila tidak ada objek terdeteksi sama sekali, pakai cadangan
                    if (fg.toFloat() / arr.size > 0.005f) return Mask(w, h, arr, false)
                }
            } finally {
                seg.close()
            }
        } catch (e: Throwable) {
            // gagal -> null
        }
        return null
    }

    /** Cadangan: warna latar diambil dari tepi gambar, lalu di-flood-fill ke dalam. */
    private fun colorMask(src: Bitmap): Mask {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val border = IntArray(2 * (w + h))
        var k = 0
        for (x in 0 until w) { border[k++] = x; border[k++] = (h - 1) * w + x }
        for (y in 0 until h) { border[k++] = y * w; border[k++] = y * w + w - 1 }

        var sr = 0L
        var sg = 0L
        var sb = 0L
        for (i in border) { val c = px[i]; sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c) }
        val mr = (sr / border.size).toInt()
        val mg = (sg / border.size).toInt()
        val mb = (sb / border.size).toInt()
        var dev = 0L
        for (i in border) {
            val c = px[i]
            dev += abs(Color.red(c) - mr) + abs(Color.green(c) - mg) + abs(Color.blue(c) - mb)
        }
        val tol = (40 + (dev / border.size).toInt() * 2).coerceIn(40, 140)

        fun near(i: Int): Boolean {
            val c = px[i]
            return abs(Color.red(c) - mr) + abs(Color.green(c) - mg) + abs(Color.blue(c) - mb) <= tol
        }

        val isBg = BooleanArray(n)
        val queue = IntArray(n)
        var qh = 0
        var qt = 0
        for (i in border) if (!isBg[i] && near(i)) { isBg[i] = true; queue[qt++] = i }
        while (qh < qt) {
            val i = queue[qh++]
            val x = i % w
            val y = i / w
            if (x > 0) { val j = i - 1; if (!isBg[j] && near(j)) { isBg[j] = true; queue[qt++] = j } }
            if (x < w - 1) { val j = i + 1; if (!isBg[j] && near(j)) { isBg[j] = true; queue[qt++] = j } }
            if (y > 0) { val j = i - w; if (!isBg[j] && near(j)) { isBg[j] = true; queue[qt++] = j } }
            if (y < h - 1) { val j = i + w; if (!isBg[j] && near(j)) { isBg[j] = true; queue[qt++] = j } }
        }
        val a = FloatArray(n) { if (isBg[it]) 0f else 1f }
        blurF(a, w, h, max(1, max(w, h) / 400))
        return Mask(w, h, a, true)
    }

    /**
     * Terapkan peta objek ke gambar: alpha akhir = alpha gambar x peta.
     * thr 0..100 (naik = potongan lebih ketat), soft 0..100 (naik = tepi lebih lembut).
     * Ukuran peta boleh berbeda dari gambar (disesuaikan).
     */
    fun apply(src: Bitmap, m: Mask, thr: Int, soft: Int): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val t = 0.2f + thr / 100f * 0.6f
        val s = 0.02f + soft / 100f * 0.4f
        val lo = t - s / 2f
        for (y in 0 until h) {
            val my = min(m.h - 1, y * m.h / h)
            for (x in 0 until w) {
                val mx = min(m.w - 1, x * m.w / w)
                val v = m.a[my * m.w + mx]
                var q = ((v - lo) / s).coerceIn(0f, 1f)
                q = q * q * (3f - 2f * q)
                val i = y * w + x
                val c = px[i]
                val na = (Color.alpha(c) * q).toInt().coerceIn(0, 255)
                px[i] = Color.argb(na, Color.red(c), Color.green(c), Color.blue(c))
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /**
     * Warna objek. ink: 0 = warna asli, 1 = hitam, 2 = putih, 3 = hitam + isi objek opak (garis tidak hilang).
     * Untuk hitam/putih, hanya garis/tinta yang dipertahankan; kertas (bagian putih) menjadi transparan.
     * paper = jenis latar kertas dari langkah 1 (0 putih, 1 krem, 2 papan tulis, 3 transparan).
     */
    fun recolor(src: Bitmap, ink: Int, paper: Int): Bitmap {
        if (ink == 0) return src
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val rgb = if (ink == 1) 20 else 255
        for (i in px.indices) {
            val c = px[i]
            val sa = c ushr 24
            if (sa == 0) continue
            val l = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
            var amt = when (paper) {
                3 -> 1f
                2 -> ((l - 60f) / 120f).coerceIn(0f, 1f)
                // Kurva lebih lunak: kulit/area terang di dalam objek tidak lagi dianggap kertas
                else -> ((1f - l / 255f - 0.04f) / 0.30f).coerceIn(0f, 1f)
            }
            // Di dalam objek (alpha tinggi) beri alpha minimum supaya wajah/lengan tidak bolong.
            // Nilai 0.25 pada tinta hitam = abu-abu terang ~ nada kulit sketsa.
            if (paper != 3 && ink == 1 && sa >= 200) amt = max(amt, 0.25f)
            if (ink == 3) {
                // Hitam + isi objek opak: di dalam objek sketsa dipertahankan apa adanya (kertas putih ikut,
                // tidak ada garis yang hilang); di tepi objek kertas dibuat transparan agar potongan bersih.
                val t = ((sa - 110f) / 140f).coerceIn(0f, 1f)
                val f = t * t * (3f - 2f * t)
                val inkAmt = if (paper == 2) ((l - 60f) / 120f).coerceIn(0f, 1f)
                else ((1f - l / 255f - 0.04f) / 0.30f).coerceIn(0f, 1f)
                val edge = if (paper == 2) 255f else 20f
                val a3 = (sa * (inkAmt * (1f - f) + f)).toInt().coerceIn(0, 255)
                val r3 = (edge * (1f - f) + Color.red(c) * f).toInt().coerceIn(0, 255)
                val g3 = (edge * (1f - f) + Color.green(c) * f).toInt().coerceIn(0, 255)
                val b3 = (edge * (1f - f) + Color.blue(c) * f).toInt().coerceIn(0, 255)
                px[i] = Color.argb(a3, r3, g3, b3)
                continue
            }
            val na = (sa * amt).toInt().coerceIn(0, 255)
            px[i] = Color.argb(na, rgb, rgb, rgb)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Pangkas ke area yang tidak transparan (agar video SpeedPaint tidak banyak ruang kosong). */
    fun cropToContent(src: Bitmap, padPct: Int = 4): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var x0 = w
        var y0 = h
        var x1 = -1
        var y1 = -1
        for (y in 0 until h) for (x in 0 until w) {
            if ((px[y * w + x] ushr 24) > 30) {
                if (x < x0) x0 = x
                if (x > x1) x1 = x
                if (y < y0) y0 = y
                if (y > y1) y1 = y
            }
        }
        if (x1 < 0) return src
        val pad = max(w, h) * padPct / 100
        val cx0 = max(0, x0 - pad)
        val cy0 = max(0, y0 - pad)
        val cx1 = min(w - 1, x1 + pad)
        val cy1 = min(h - 1, y1 + pad)
        val cw = max(2, cx1 - cx0 + 1)
        val ch = max(2, cy1 - cy0 + 1)
        if (cx0 + cw > w || cy0 + ch > h) return src
        return Bitmap.createBitmap(src, cx0, cy0, cw, ch)
    }

    /** Gambar transparan di atas pola kotak-kotak (hanya untuk tampilan pratinjau). */
    fun onChecker(src: Bitmap, dark: Boolean = false): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint()
        val cell = max(8, max(w, h) / 40)
        var yy = 0
        var row = 0
        while (yy < h) {
            var xx = 0
            var col = 0
            while (xx < w) {
                p.color = if (dark) { if ((row + col) % 2 == 0) 0xFF4A4A4A.toInt() else 0xFF303030.toInt() }
                else { if ((row + col) % 2 == 0) 0xFFFFFFFF.toInt() else 0xFFD9D9D9.toInt() }
                c.drawRect(xx.toFloat(), yy.toFloat(), (xx + cell).toFloat(), (yy + cell).toFloat(), p)
                xx += cell
                col++
            }
            yy += cell
            row++
        }
        c.drawBitmap(src, 0f, 0f, null)
        return out
    }

    private fun blurF(a: FloatArray, w: Int, h: Int, r: Int) {
        val tmp = FloatArray(max(w, h))
        val k = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            val o = y * w
            var sum = 0f
            for (i in -r..r) sum += a[o + i.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[x] = sum / k
                sum += a[o + min(x + r + 1, w - 1)] - a[o + max(x - r, 0)]
            }
            System.arraycopy(tmp, 0, a, o, w)
        }
        for (x in 0 until w) {
            var sum = 0f
            for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                tmp[y] = sum / k
                sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
            }
            for (y in 0 until h) a[y * w + x] = tmp[y]
        }
    }
}
