plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ims.jpgtosketsa"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.ims.jpgtosketsa"
        minSdk = 29
        targetSdk = 34
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        versionCode = 28
        versionName = "4.8"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("onnx") }
}
dependencies {
    // Penghapus latar belakang (langkah 2): berjalan di HP lewat Google Play services
    implementation("com.google.android.gms:play-services-mlkit-subject-segmentation:16.0.0-beta1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
    // Model AI offline (Arsir + AI)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.18.0")
}
